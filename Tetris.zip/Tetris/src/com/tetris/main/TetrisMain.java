package com.tetris.main;

import com.tetris.window.Tetris;

public class TetrisMain{
	public static void main(String[] args){
		new Tetris();
	}
}